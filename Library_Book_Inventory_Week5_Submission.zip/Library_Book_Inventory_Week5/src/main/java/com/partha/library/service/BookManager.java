package com.partha.library.service;

import com.partha.library.model.Book;
import com.partha.library.util.InputValidator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

/**
 * Manages all book inventory operations.
 *
 * Week 4 refactoring:
 * - Uses a Map keyed by normalized ISBN for O(1) average lookup.
 * - Keeps validation in InputValidator.
 * - Uses small single-purpose methods.
 * - Prevents callers from modifying internal state directly.
 */
public class BookManager {

    private final Map<String, Book> booksByIsbn = new LinkedHashMap<>();

    /**
     * Adds a book using ISBN as the unique key.
     */
    public void addBook(Book book) {
        validateBook(book);

        String isbn = normalizeIsbn(book.getIsbn());
        if (booksByIsbn.containsKey(isbn)) {
            throw new IllegalArgumentException("A book with ISBN " + isbn + " already exists.");
        }

        booksByIsbn.put(isbn, book);
    }

    /**
     * Returns a read-only snapshot of the current inventory.
     */
    public List<Book> getAllBooks() {
        return Collections.unmodifiableList(new ArrayList<>(booksByIsbn.values()));
    }

    /**
     * Average lookup time is O(1), compared with O(n) ArrayList scanning.
     */
    public Book findBookByIsbn(String isbn) {
        return booksByIsbn.get(normalizeIsbn(isbn));
    }

    /**
     * Updates mutable book fields while preserving the ISBN.
     */
    public void updateBook(String isbn, String title, String author, int quantity) {
        Book book = requireExistingBook(isbn);

        book.setTitle(InputValidator.requireText(title, "Title"));
        book.setAuthor(InputValidator.requireText(author, "Author"));
        book.setQuantity(InputValidator.requireNonNegative(quantity, "Quantity"));
    }

    /**
     * Deletes a book by ISBN.
     */
    public void deleteBook(String isbn) {
        String normalizedIsbn = normalizeIsbn(isbn);
        if (booksByIsbn.remove(normalizedIsbn) == null) {
            throw new IllegalArgumentException("Book with ISBN " + normalizedIsbn + " not found.");
        }
    }

    public int getBookCount() {
        return booksByIsbn.size();
    }

    private Book requireExistingBook(String isbn) {
        String normalizedIsbn = normalizeIsbn(isbn);
        Book book = booksByIsbn.get(normalizedIsbn);

        if (book == null) {
            throw new IllegalArgumentException("Book with ISBN " + normalizedIsbn + " not found.");
        }

        return book;
    }

    private void validateBook(Book book) {
        if (book == null) {
            throw new IllegalArgumentException("Book cannot be null.");
        }

        InputValidator.requireText(book.getIsbn(), "ISBN");
        InputValidator.requireText(book.getTitle(), "Title");
        InputValidator.requireText(book.getAuthor(), "Author");
        InputValidator.requireNonNegative(book.getQuantity(), "Quantity");
    }

    private String normalizeIsbn(String isbn) {
        return InputValidator.normalizeIsbn(isbn);
    }
}
