package com.partha.library;

import com.partha.library.model.Book;
import com.partha.library.service.BookManager;

import java.util.Scanner;

/**
 * Command-line entry point for the Week 4 refactored application.
 */
public class Main {

    private static final String EXIT_OPTION = "0";

    public static void main(String[] args) {
        BookManager manager = new BookManager();

        // Sample data makes the application easy to demonstrate.
        manager.addBook(new Book("ISBN001", "Clean Code", "Robert C. Martin", 5));
        manager.addBook(new Book("ISBN002", "Effective Java", "Joshua Bloch", 3));

        runMenu(manager);
    }

    private static void runMenu(BookManager manager) {
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                printMenu();
                String choice = scanner.nextLine().trim();

                try {
                    if (EXIT_OPTION.equals(choice)) {
                        System.out.println("Application closed.");
                        return;
                    }

                    handleChoice(choice, scanner, manager);
                } catch (IllegalArgumentException ex) {
                    System.out.println("Error: " + ex.getMessage());
                }
            }
        }
    }

    private static void printMenu() {
        System.out.println("\n===== Library Book Inventory =====");
        System.out.println("1. Add Book");
        System.out.println("2. View All Books");
        System.out.println("3. Find Book");
        System.out.println("4. Update Book");
        System.out.println("5. Delete Book");
        System.out.println("0. Exit");
        System.out.print("Enter choice: ");
    }

    private static void handleChoice(String choice, Scanner scanner, BookManager manager) {
        switch (choice) {
            case "1" -> addBook(scanner, manager);
            case "2" -> viewBooks(manager);
            case "3" -> findBook(scanner, manager);
            case "4" -> updateBook(scanner, manager);
            case "5" -> deleteBook(scanner, manager);
            default -> System.out.println("Invalid menu option.");
        }
    }

    private static void addBook(Scanner scanner, BookManager manager) {
        String isbn = read(scanner, "ISBN: ");
        String title = read(scanner, "Title: ");
        String author = read(scanner, "Author: ");
        int quantity = readInt(scanner, "Quantity: ");

        manager.addBook(new Book(isbn, title, author, quantity));
        System.out.println("Book added successfully.");
    }

    private static void viewBooks(BookManager manager) {
        if (manager.getAllBooks().isEmpty()) {
            System.out.println("No books available.");
            return;
        }

        manager.getAllBooks().forEach(System.out::println);
    }

    private static void findBook(Scanner scanner, BookManager manager) {
        String isbn = read(scanner, "ISBN: ");
        Book book = manager.findBookByIsbn(isbn);

        System.out.println(book == null ? "Book not found." : book);
    }

    private static void updateBook(Scanner scanner, BookManager manager) {
        String isbn = read(scanner, "ISBN to update: ");
        String title = read(scanner, "New title: ");
        String author = read(scanner, "New author: ");
        int quantity = readInt(scanner, "New quantity: ");

        manager.updateBook(isbn, title, author, quantity);
        System.out.println("Book updated successfully.");
    }

    private static void deleteBook(Scanner scanner, BookManager manager) {
        String isbn = read(scanner, "ISBN to delete: ");
        manager.deleteBook(isbn);
        System.out.println("Book deleted successfully.");
    }

    private static String read(Scanner scanner, String message) {
        System.out.print(message);
        return scanner.nextLine();
    }

    private static int readInt(Scanner scanner, String message) {
        String value = read(scanner, message);
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Please enter a valid integer.");
        }
    }
}
