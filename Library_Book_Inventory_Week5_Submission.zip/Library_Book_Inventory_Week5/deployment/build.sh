#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="$ROOT_DIR/build/classes"
DIST_DIR="$ROOT_DIR/dist"
JAR_FILE="$DIST_DIR/library-book-inventory.jar"

rm -rf "$ROOT_DIR/build"
mkdir -p "$BUILD_DIR" "$DIST_DIR"

find "$ROOT_DIR/src/main/java" -name "*.java" -print0 | xargs -0 javac -encoding UTF-8 -d "$BUILD_DIR"

cat > "$ROOT_DIR/build/manifest.mf" <<MANIFEST
Manifest-Version: 1.0
Main-Class: com.partha.library.Main
MANIFEST

rm -f "$JAR_FILE"
jar cfm "$JAR_FILE" "$ROOT_DIR/build/manifest.mf" -C "$BUILD_DIR" .

echo "Build successful: $JAR_FILE"
