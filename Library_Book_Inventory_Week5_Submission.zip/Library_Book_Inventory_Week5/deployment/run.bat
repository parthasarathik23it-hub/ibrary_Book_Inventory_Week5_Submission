@echo off
setlocal
set ROOT_DIR=%~dp0..
set JAR_FILE=%ROOT_DIR%dist\library-book-inventory.jar

if not exist "%JAR_FILE%" (
  echo JAR not found. Run deployment\build.bat first.
  exit /b 1
)

java -jar "%JAR_FILE%"
endlocal
