@echo off
setlocal
set ROOT_DIR=%~dp0..
set BUILD_DIR=%ROOT_DIR%build\classes
set DIST_DIR=%ROOT_DIR%dist
set JAR_FILE=%DIST_DIR%\library-book-inventory.jar

if exist "%ROOT_DIR%build" rmdir /s /q "%ROOT_DIR%build"
if not exist "%BUILD_DIR%" mkdir "%BUILD_DIR%"
if not exist "%DIST_DIR%" mkdir "%DIST_DIR%"

for /R "%ROOT_DIR%src\main\java" %%F in (*.java) do javac -encoding UTF-8 -d "%BUILD_DIR%" "%%F"
if errorlevel 1 exit /b 1

echo Manifest-Version: 1.0> "%ROOT_DIR%build\manifest.mf"
echo Main-Class: com.partha.library.Main>> "%ROOT_DIR%build\manifest.mf"

if exist "%JAR_FILE%" del /q "%JAR_FILE%"
jar cfm "%JAR_FILE%" "%ROOT_DIR%build\manifest.mf" -C "%BUILD_DIR%" .
if errorlevel 1 exit /b 1

echo Build successful: %JAR_FILE%
endlocal
