#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
JAR_FILE="$ROOT_DIR/dist/library-book-inventory.jar"

if [ ! -f "$JAR_FILE" ]; then
  echo "JAR not found. Run deployment/build.sh first."
  exit 1
fi

java -jar "$JAR_FILE"
